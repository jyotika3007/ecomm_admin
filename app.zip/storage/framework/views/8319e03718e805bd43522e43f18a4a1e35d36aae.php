

<?php $__env->startSection('navbar'); ?>
<?php echo $__env->make('admin.includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
				<form class="form-horizontal" action="<?php echo e(route('category.store')); ?>" method="POST" enctype="multipart/form-data"> 
	<div class="row justify-content-center">
		<div class="col-md-8">
			<div class="card">
				<h2>Add New Category</h2>
					<?php echo e(csrf_field()); ?>

					<div class="form-group">
						<label class="control-label col-sm-2" for="category_name">Category Name:</label>
						<div class="col-sm-10">
							<input type="text" class="form-control" id="category_name" placeholder="Enter Category Name" name="category_name">
						</div>
					</div>
					<div class="form-group">
						<label class="control-label col-sm-2" for="cover_image">Cover Image (Optional):</label>
						<div class="col-sm-10">          
							<input type="file" class="form-control" id="cover_image" placeholder="Enter password" name="cover_image">
						</div>
					</div> 
					<div class="form-group">
						<label class="control-label col-sm-2" for="is_active">Status:</label>
						<div class="col-sm-10">          
							<select class="form-control" id="is_active" name="is_active" >

								<option value="1">Enable</option>
								<option value="0">Disable</option>

							</select>
						</div>
					</div>

					<div class="form-group">        
						<div class="col-sm-offset-2 col-sm-10">
							<button type="submit" class="btn btn-default">Submit</button>
						</div>
					</div>
			</div>
		</div>


		<div class="col-md-4">
			<h2> Parent Category </h2>
				<ul>
			<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li style="position : relative"><input type="checkbox" value="<?php echo e($category->id); ?>" name="parent_id"  /> &nbsp<?php echo e($category->category_name ?? ''); ?> <span style="position: absolute; right: 0; cursor: pointer"> <i class="fa fa-angle-down" onclick="getChildCategories(<?php echo e($category->id); ?>)"></i> </span><div id="subList<?php echo e($category->id); ?>"></div></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>

		</div>

				</form>
	</div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>

<script type="text/javascript" src="<?php echo e(asset('js/script.js')); ?>"></script>	

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\exercise\admin\resources\views/admin/categories/add.blade.php ENDPATH**/ ?>