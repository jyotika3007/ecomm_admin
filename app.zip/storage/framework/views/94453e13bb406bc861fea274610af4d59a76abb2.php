

<?php $__env->startSection('navbar'); ?>
<?php echo $__env->make('admin.includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>



<div class="container">
<?php echo $__env->make('admin.includes.errors-and-messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row justify-content-center">
        <h2>Products List

            <span style="margin-left: 75%" id="export" data-href="/tasks" class="btn btn-warning btn-sm" onclick="exportTasks(event.target);">Export</span>

        </h2>


        <div class="col-md-12">
            <div class="card">
            	<table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>#</th>
                <th>Product Name </th>
                <th>Category</th>
                <th>Stock</th>
                <th>Cover Image</th>
                <th>Created_at</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($product->id ?? '0'); ?></td>
                <td><?php echo e($product->name ?? ''); ?></td>
                <td><?php echo e($product->category_name ?? ''); ?></td>
                <td><?php echo e($product->stock ?? ''); ?></td>
                <td><?php if($product->cover_image != ''): ?>
                 <img src="<?php echo e(asset('/storage/products/'.$product->cover_image)); ?>" style="height: 100px ; width: auto" />
                 <?php endif; ?>
                </td>
                <td><?php echo e($product->created_at ?? ''); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </tbody>

    </table>
               
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    <script>
   function exportTasks(_this) {
      let _url = $(_this).data('href');
      window.location.href = _url;


      // $.ajax({
      //   type: "GET",
      //   data: {},
      //   url: '/tasks',
      //   success:function(response){
      //       console.log(response)
      //   }
      // })



   }
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\exercise\admin\resources\views/admin/products/list.blade.php ENDPATH**/ ?>