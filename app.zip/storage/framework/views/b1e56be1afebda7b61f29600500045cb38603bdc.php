<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Welcome</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="<?php echo e(url('/home')); ?>">Dashboard</a></li>
      <li><a href="<?php echo e(route('category.index')); ?>">Categories List</a></li>
      <li><a href="<?php echo e(route('category.create')); ?>">ADD Category</a></li>
      <li><a href="<?php echo e(route('product.index')); ?>">Products List</a></li>
      <li><a href="<?php echo e(route('product.create')); ?>">Add Product</a></li>
      <li><a href="<?php echo e(route('category.products')); ?>">Categorywise Products List</a></li>
    </ul>
    <ul class="float-right">
      <li>

         <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                        <button type="submit" name="Logout" class="btn btn-primary">Logout</button>
                    </form>

      </li>
      <li style="margin-top: 15px"><a href="#"></a> <i class="fa fa-user"></i> <?php echo e(Auth::user()->name); ?></li>
    </ul>      
  </div>
</nav>

<style type="text/css">
    .float-right{
      list-style-type: none;
      color: #fff;
    }
    .float-right li{
      float: right;
      margin-top: 7px;
      margin-right: 10px
    }
</style>
  <?php /**PATH C:\xampp\htdocs\exercise\admin\resources\views/admin/includes/navbar.blade.php ENDPATH**/ ?>