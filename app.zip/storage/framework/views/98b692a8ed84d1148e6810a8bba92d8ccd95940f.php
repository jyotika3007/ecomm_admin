

<?php $__env->startSection('navbar'); ?>
<?php echo $__env->make('admin.includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<link  href="https://cdnjs.cloudflare.com/ajax/libs/dropzone/4.3.0/dropzone.css"  rel="stylesheet">  

<script  src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/4.3.0/dropzone.js"></script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row justify-content-center">
		<div class="col-md-12">

			<ul class="nav nav-tabs">
				<li><a data-toggle="tab" href="#home">Edit Product</a></li>
				<li class="active"><a data-toggle="tab" href="#menu1">Cover Images</a></li>
			</ul>

			<div class="tab-content">
				<div id="home" class="tab-pane">
					<form class="form-horizontal" action="<?php echo e(route('product.store')); ?>" method="POST"> 

						<div class="row">							

							<div class="col-sm-8">
								<div class="card">
									<h2>Edit Product</h2>
									<?php echo e(csrf_field()); ?>

									<div class="form-group">
										<label class="control-label col-sm-2" for="name">Product Name:</label>
										<div class="col-sm-10">
											<input type="text" class="form-control" id="name" value="<?php echo e($product->name ?? ''); ?>" placeholder="Enter Product Name" name="name" required="required">
										</div>
									</div>

									<div class="form-group">
										<label class="control-label col-sm-2" for="price">Price:</label>
										<div class="col-sm-10">
											<input type="number" step="0.1" class="form-control" id="price" placeholder="Enter Product Price" name="price" required="required"  value="<?php echo e($product->price ?? ''); ?>">
										</div>
									</div>

									<div class="form-group">
										<label class="control-label col-sm-2" for="stock">Quantity (In Stock):</label>
										<div class="col-sm-10">
											<input type="number" class="form-control" id="stock" placeholder="Enter Stock " name="stock" required="required" value="<?php echo e($product->stock ?? ''); ?>">
										</div>
									</div>
									
									<div class="form-group">
										<label class="control-label col-sm-2" for="is_active">Status:</label>
										<div class="col-sm-10">          
											<select class="form-control" id="is_active" name="is_active" >

												<option value="1" <?php if($product->is_active == 1): ?>'selected'<?php endif; ?>>Enable</option>
												<option value="0" <?php if($product->is_active == 0): ?>'selected'<?php endif; ?>>Disable</option>

											</select>
										</div>
									</div>

									<div class="form-group">        
										<div class="col-sm-offset-2 col-sm-10">
											<button type="submit" class="btn btn-default">Submit</button>
										</div>
									</div>
								</div>
							</div>

							<div class="col-md-4">
								<h2> Parent Category </h2>
								<ul>
									<li><?php echo e($product->category_name ?? ''); ?></li>
								</ul>

							</div>

						</div>

					</form>
				</div>
				<div id="menu1" class="tab-pane fade in active">
					<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h4>Upload Multiple Images using dropzone.js and Laravel</h4>
            <form id="image-upload" action="<?php echo e(route('dropzone.store',$product->id)); ?>" method="POST" enctype="multipart/form-data" class="dropzone form-control">

            	<?php echo e(csrf_field()); ?>

            	
            <div>
                <h5>Upload Multiple Image By Click On Box</h5>
            </div>
            
            </form>
           
        </div>
    </div>
</div>
				</div>

			</div>


		</div>


	</div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>

<script type="text/javascript" src="<?php echo e(asset('js/script.js')); ?>"></script>	

<script type="text/javascript">
        Dropzone.options.imageUpload = {
            maxFilesize         :       1,
            acceptedFiles: ".jpeg,.jpg,.png,.gif"
        };
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\exercise\admin\resources\views/admin/products/edit.blade.php ENDPATH**/ ?>