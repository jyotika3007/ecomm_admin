
<h3>Steps to be followed to run project</h3>
<ul>
	<li>composer install</li>
	<li>
		php artisan migrate
	</li>
	<li>
		php artisan db:seed
	</li>
	
</ul>